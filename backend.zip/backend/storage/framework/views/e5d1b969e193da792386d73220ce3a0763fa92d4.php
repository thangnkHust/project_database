<!DOCTYPE HTML>
<html>


<head>
    <?php echo $__env->make('web/elements/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

	<div id="fb-root"></div>

	<div class="colorlib-loader"></div>

	<div id="page">
		<nav class="colorlib-nav" role="navigation">
			<?php echo $__env->make('web/elements/navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        
        
		<?php echo $__env->yieldContent('slider'); ?>

		<div id="colorlib-intro">
            
            
            <?php echo $__env->yieldContent('content'); ?>

            
            <div id="colorlib-subscribe" class="subs-img" style="background-image: url(<?php echo e(asset('front_page/images/img_bg_2.jpg')); ?>);" data-stellar-background-ratio="0.5">
                <?php echo $__env->make('web/elements/subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            
			<footer id="colorlib-footer">
				<?php echo $__env->make('web/elements/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</footer>
		</div>

		<div class="gototop js-top">
			<a href="#" class="js-gotop">
				<i class="icon-arrow-up2"></i>
			</a>
		</div>
	</div>

        
		<?php echo $__env->make('web/elements/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/main.blade.php ENDPATH**/ ?>