<?php if(session('notify')): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session('notify')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/templates/notify.blade.php ENDPATH**/ ?>