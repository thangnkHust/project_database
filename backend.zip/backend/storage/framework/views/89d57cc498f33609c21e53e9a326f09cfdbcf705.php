
<div class="x_title">
    <h2><?php echo e($title); ?></h2>
    <ul class="nav navbar-right panel_toolbox">
        <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
        </li>

    </ul>
    <div class="clearfix"></div>
</div><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/templates/x-title.blade.php ENDPATH**/ ?>