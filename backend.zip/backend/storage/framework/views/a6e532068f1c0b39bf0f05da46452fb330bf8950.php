<!-- jQuery -->
<script src="<?php echo e(asset('front_page/js/jquery.min.js')); ?>"></script>
<!-- jQuery Easing -->
<script src="<?php echo e(asset('front_page/js/jquery.easing.1.3.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('front_page/js/bootstrap.min.js')); ?>"></script>
<!-- Waypoints -->
<script src="<?php echo e(asset('front_page/js/jquery.waypoints.min.js')); ?>"></script>
<!-- Stellar Parallax -->
<script src="<?php echo e(asset('front_page/js/jquery.stellar.min.js')); ?>"></script>
<!-- Flexslider -->
<script src="<?php echo e(asset('front_page/js/jquery.flexslider-min.js')); ?>"></script>
<!-- Owl carousel -->
<script src="<?php echo e(asset('front_page/js/owl.carousel.min.js')); ?>"></script>
<!-- Magnific Popup -->
<script src="<?php echo e(asset('front_page/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_page/js/magnific-popup-options.js')); ?>"></script>
<!-- Counters -->
<script src="<?php echo e(asset('front_page/js/jquery.countTo.js')); ?>"></script>
<!-- Main -->
<script src="<?php echo e(asset('front_page/js/main.js')); ?>"></script>
<!-- Modernizr JS -->
<script src="<?php echo e(asset('front_page/js/modernizr-2.6.2.min.js')); ?>"></script>
<!-- FOR IE9 below -->
<!--[if lt IE 9]>
<script src="js/respond.min.js"></script>
<![endif]-->



<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v5.0&appId=497438537643875&autoLogAppEvents=1"></script><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/elements/script.blade.php ENDPATH**/ ?>