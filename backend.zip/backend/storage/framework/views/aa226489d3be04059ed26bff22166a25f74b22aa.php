<?php if(session('notify')): ?>
    <div class="alert alert-danger" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="close">
            <span aria-hidden="true">x</span>
        </button>
        <strong><?php echo e(session('notify')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/templates/alert.blade.php ENDPATH**/ ?>