<?php if($items->lastPage() > 1): ?>
    <ul class="pagination" style="float: right">
        <?php if($items->currentPage() == 1): ?>
            <li class="disabled">
                <a>Previous</a>
            </li>
        <?php else: ?>
            <li>
                
                <a href="<?php echo e($items->url($items->currentPage()-1)); ?>" class="page">Previous</a>
            </li>
        <?php endif; ?>
        <?php for($i = 1; $i <= $items->lastPage(); $i++): ?>
            <li class="<?php echo e(($items->currentPage() == $i) ? ' active' : ''); ?>">
                <a href="<?php echo e($items->url($i)); ?>" class="page">Page<?php echo e($i); ?></a>
            </li>
        <?php endfor; ?>
        <?php if($items->currentPage() == $items->lastPage()): ?>
            <li class="disabled">
                <a >Next</a>
            </li>
        <?php else: ?>
            <li>
                <a href="<?php echo e($items->url($items->currentPage()+1)); ?>" class="page">Next</a>
            </li>
        <?php endif; ?>
    </ul>
<?php endif; ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/pagination/pagination_backend.blade.php ENDPATH**/ ?>