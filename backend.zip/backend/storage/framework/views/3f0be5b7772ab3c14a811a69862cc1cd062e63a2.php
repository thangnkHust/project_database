
<tr>
    <td colspan="<?php echo e($colspan); ?>" class="text-center">Du lieu dang duoc cap nhat...</td>
</tr><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/templates/list_empty.blade.php ENDPATH**/ ?>