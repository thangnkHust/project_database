<!-- jQuery -->
<script src="<?php echo e(asset('admin_page/js/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('admin_page/asset/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('admin_page/js/fastclick/lib/fastclick.js')); ?>"></script>
<!-- NProgress -->
<script src="<?php echo e(asset('admin_page/asset/nprogress/nprogress.js')); ?>"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo e(asset('admin_page/asset/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>"></script>
<!-- iCheck -->
<script src="<?php echo e(asset('admin_page/asset/iCheck/icheck.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_page/js/ckeditor/ckeditor.js')); ?>"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo e(asset('admin_page/js/custom.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_page/js/my-js.js')); ?>"></script><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/elements/script.blade.php ENDPATH**/ ?>