<?php $__env->startSection('slider'); ?>
    <aside id="colorlib-hero">
        <div class="flexslider">
            <ul class="slides">
            <li style="background-image: url(<?php echo e(asset('front_page/images/img_bg_2.jpg')); ?>);">
                <div class="overlay"></div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6 col-sm-12 col-md-offset-3 slider-text">
                            <div class="slider-text-inner text-center">
                                <h1><?php echo e($item['name']); ?></h1>
                                <h2><span><a href="<?php echo e(route('home')); ?>">TRANG CHỦ</a> | <a href="<?php echo e(route('post/subject', ['subject_name' => $params['subject_name'], 'subject_id' => $params['subject_id']])); ?>"> <?php echo e($item->subject->name); ?></a> | <?php echo e($item['name']); ?></span></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            </ul>
        </div>
    </aside>
<?php $__env->stopSection(); ?>
        
<?php $__env->startSection('content'); ?>
<div class="colorlib-classes">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-md-offset-1">
                <div class="row row-pb-lg">
                    <div class="col-md-10 animate-box">
                        <div class="classes class-single">
                            <div class="classes-img" style="background-image: url(<?php echo e(asset('images/post/' . $item['thumb'])); ?>);">
                                <span class="price text-center"><small>Free</small></span>
                            </div>
                            <div class="desc desc2">
                                <h3><a><?php echo e($item['name']); ?></a></h3>
                                
                                <?php echo $item['content']; ?>

                                
                            </div>
                        </div>
                    </div>
                </div>


                
                <div class="row row-pb-lg animate-box">
                    <div class="col-md-10">
                        <div class="review">
                            <div class="fb-comments" data-href="<?php echo e(route('post/post',[
                                'subject_id' => $params['subject_id'],
                                'subject_name' => $params['subject_name'],
                                'post_id' => $params['post_id'],
                                'post_name' => $params['post_name']
                            ])); ?>" data-width="100%" data-numposts="5"></div>
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </div>	
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/pages/post/post.blade.php ENDPATH**/ ?>