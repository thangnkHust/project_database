<?php $__env->startSection('content'); ?>
    <div class="page-header zvn-page-header clearfix">
        <div class="zvn-page-header-title">
            <h3>User Management</h3>
        </div>
        <div class="zvn-add-new pull-right">
            <a href="<?php echo e(route($controllerName)); ?>" class="btn btn-info"><i
                    class="fa fa-arrow-left"></i> Back</a>
        </div>
    </div>

    <?php echo $__env->make('admin/templates.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($item['id']): ?>
        <div class="row">
            <?php echo $__env->make('admin/pages/user.form_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin/pages/user.form_change_password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin/pages/user.form_change_level', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php else: ?>
        <?php echo $__env->make('admin/pages/user.form_add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/pages/user/form.blade.php ENDPATH**/ ?>