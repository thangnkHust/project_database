<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('admin/elements.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="nav-sm">
    
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col" style="position: fixed">
            <div class="left_col scroll-view">
                <?php echo $__env->make('admin/elements/sidebar_title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('admin/elements/sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <!-- top navigation -->
        <div class="top_nav">
            <?php echo $__env->make('admin/elements.top_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
        <div class="right_col" role="main">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <footer>
            <?php echo $__env->make('admin/elements.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
        <!-- /footer -->
    </div>
</div>
<?php echo $__env->make('admin/elements.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/main.blade.php ENDPATH**/ ?>