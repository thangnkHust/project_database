<?php $__env->startSection('slider'); ?>
<aside id="colorlib-hero">
    <div class="flexslider">
        <ul class="slides">
        <li style="background-image: url(<?php echo e(asset('front_page/images/img_bg_2.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-md-offset-3 slider-text">
                        <div class="slider-text-inner text-center">
                            <h1>Về Chúng Tôi</h1>
                            <h2><span><a href="<?php echo e(route('home')); ?>">Trang chủ</a> | Thông tin</span></h2>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        </ul>
    </div>
</aside>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div id="colorlib-contact">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 animate-box">
                <?php echo $__env->make('web/templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('web/templates.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h2>Thông tin tài khoản</h2>
                <?php echo Form::open([
                    'url' => route("auth/postPass"),
                    'method' => 'POST',
                    'accept-charset' => 'UTF-8',
                    'enctype' => 'multipart/form-data',
                    // 'class' => 'form-horizontal form-label-left',
                    // 'id' => 'main-form'
                ]); ?>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <?php echo Form::password('password_current', ['class' => 'form-control', 'placeholder' => 'Nhập tên mât khẩu hiện tại', 'required' => 'required', 'style' => 'height:50px']); ?>

                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <?php echo Form::password('password_new', ['class' => 'form-control', 'placeholder' => 'Nhập mật khẩu mới', 'required' => 'required', 'style' => 'height:50px']); ?>

                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <?php echo Form::password('password_new_confirm', ['class' => 'form-control', 'placeholder' => 'Nhập lại mật khẩu mới', 'required' => 'required', 'style' => 'height:50px']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <?php echo Form::submit('Gửi', ['class' => 'btn btn-primary']); ?>

                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/pages/auth/pass.blade.php ENDPATH**/ ?>