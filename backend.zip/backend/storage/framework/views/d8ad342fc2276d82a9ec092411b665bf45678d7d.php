<?php $__env->startSection('slider'); ?>
<aside id="colorlib-hero">
    <div class="flexslider">
        <ul class="slides">
        <li style="background-image: url(<?php echo e(asset('front_page/images/img_bg_2.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-md-offset-3 slider-text">
                        <div class="slider-text-inner text-center">
                            <h1>HỌC TẬP</h1>
                            <h2><span><a href="<?php echo e(route('home')); ?>">Trang chủ</a> | <?php echo e($items[0]->subject->name); ?></span></h2>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        </ul>
    </div>
</aside>
<?php $__env->stopSection(); ?>

<?php
    use App\Helpers\URL as URL;
    $listPost = '';
    foreach ($items as $item) {
        $link = URL::linkExamDetail($item->subject->id, $item->subject->name, $item['id'], $item['name']);
        $listPost .= sprintf(
            '<div class="col-md-4 animate-box">
                <div class="classes">
                    <div class="classes-img" style="background-image: url(%s);">
                        <span class="price text-center"><small>Free</small></span>
                    </div>
                    <div class="desc">
                        <h3><a href="%s">%s</a></h3>
                        <p><i class="fa fa-eye"></i> %s</p>
                    </div>
                </div>
            </div>', asset('images/exam/' . $item['thumb']), $link, $item['name'], $item['viewed']);
    }
?>


<?php $__env->startSection('content'); ?>
<div class="colorlib-classes">
    <div class="container">
        <div class="row">
            <?php echo $listPost; ?>

        </div>
    </div>	
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/pages/exam/index.blade.php ENDPATH**/ ?>