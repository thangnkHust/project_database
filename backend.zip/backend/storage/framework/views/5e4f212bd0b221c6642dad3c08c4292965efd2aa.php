<?php $__env->startSection('slider'); ?>
<aside id="colorlib-hero">
    <div class="flexslider">
        <ul class="slides">
        <li style="background-image: url(<?php echo e(asset('front_page/images/img_bg_2.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-md-offset-3 slider-text">
                        <div class="slider-text-inner text-center">
                            <h1>Về Chúng Tôi</h1>
                            <h2><span><a href="<?php echo e(route('home')); ?>">Trang chủ</a> | Liên Hệ</span></h2>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        </ul>
    </div>
</aside>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div id="colorlib-contact">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 animate-box">
                <h2>Thông tin liên lạc</h2>
                <div class="row">
                    <div class="col-md-12">
                        <div class="contact-info-wrap-flex">
                            <div class="con-info">
                                <p><span><i class="icon-location-2"></i></span> Số 1 Đại Cồ Việt, <br> Quận Hai Bà Trưng, Hà Nội</p>
                            </div>
                            <div class="con-info">
                                <p><span><i class="icon-phone3"></i></span> <a href="tel://0982999999">0982.999.999</a></p>
                            </div>
                            <div class="con-info">
                                <p><span><i class="icon-paperplane"></i></span> <a href="mailto:elearning.website.project@gmail.com"> elearning.website</a></p>
                            </div>
                            <div class="con-info">
                                <p><span><i class="icon-globe"></i></span> <a href="#"> elearning.com</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-10 col-md-offset-1 animate-box">
                <h2>Phản hồi cho chúng tôi</h2>
                <?php echo Form::open([
                    'url' => route("$controllerName/feadback"),
                    'method' => 'POST',
                    'accept-charset' => 'UTF-8',
                    'enctype' => 'multipart/form-data',
                    // 'class' => 'form-horizontal form-label-left',
                    // 'id' => 'main-form'
                ]); ?>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <?php echo Form::text('fullname', '', ['class' => 'form-control', 'placeholder' => 'Nhập họ và tên bạn', 'required' => 'required']); ?>

                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <?php echo Form::email('email', '', ['class' => 'form-control', 'placeholder' => 'Nhập Email', 'required' => 'required', 'style' => 'height:50px']); ?>

                            
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <?php echo Form::text('subject', '', ['class' => 'form-control', 'placeholder' => 'Nhập chủ đề', 'required' => 'required']); ?>

                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                            <?php echo Form::textarea('content', '', ['class' => 'form-control', 'placeholder' => 'Hãy viết những ý kiến của bạn về chất lượng của trang web', 'cols' => 30, 'rows' => 10, 'required' => 'required']); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <?php echo Form::submit('Gửi', ['class' => 'btn btn-primary']); ?>

                    </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/pages/contact/index.blade.php ENDPATH**/ ?>