<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="close">
            <span aria-hidden="true">x</span>
        </button>
        <strong><?php echo e(session('success')); ?></strong>
    </div>
<?php endif; ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/templates/success.blade.php ENDPATH**/ ?>