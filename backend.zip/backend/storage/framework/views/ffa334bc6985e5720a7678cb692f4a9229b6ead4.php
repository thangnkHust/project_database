<?php
    use App\Helpers\template as template;
    use App\Helpers\hightlight as hightlight;
?>


<div class="x_content">
        <div class="table-responsive">
            <table class="table table-striped jambo_table bulk_action">
                <thead>
                <tr class="headings">
                    <th class="column-title">#</th>
                    <th class="column-title">Subject</th>
                    <th class="column-title">Name Exam</th>
                    <th class="column-title">Question</th>
                    <th class="column-title">Answer</th>
                    <th class="column-title">Created at</th>
                    <th class="column-title">Updated at</th>
                    <th class="column-title">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php if(count($items) > 0): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $index = $key + 1;
                            $id = $val->id;
                            $nameSubject = $val->exam->subject->name;
                            $nameExam = $val->exam->name;
                            $question = $val->question;
                            $answer_a = $val->answer_a;
                            $answer_b = $val->answer_b;
                            $answer_c = $val->answer_c;
                            $answer_d = $val->answer_d;
                            $correct_answer = $val->correct_answer;
                            $test = ['A', 'B', 'C', 'D'];
                            // $name = hightlight::show($val->name, $params['search'], 'question');
                            $createdHistory = template::showItemHistory($val->created_at);
                            $updatedHistory = template::showItemHistory($val->updated_at);
                            $listButtonAction = template::showActionButton($controllerName, $id);
                        ?>

                        <tr class="even pointer">
                            <td class="" width="2%"><?php echo e($index); ?></td>
        
                            <td width="8%">
                                <?php echo $nameSubject; ?>

                            </td>

                            <td width="20%">
                                <?php echo $nameExam; ?>

                            </td>

                            <td width="39%">
                                <p><strong>Question: </strong> <?php echo $question; ?></p>
                                <p><strong>A: </strong><?php echo $answer_a; ?></p>
                                <p><strong>B: </strong><?php echo $answer_b; ?></p>
                                <p><strong>C: </strong><?php echo $answer_c; ?></p>
                                <p><strong>D: </strong><?php echo $answer_d; ?></p>
                            </td>

                            <td width="5%">
                                <?php echo $test[$correct_answer - 1]; ?>

                            </td>
        
                            <td width="8%">
                                <?php echo $createdHistory; ?>

                            </td>
        
                            <td width="8%">
                                <?php echo $updatedHistory; ?>

                            </td>
        
                            <td class="last" width="10%">
                                <?php echo $listButtonAction; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?> 
                    
                    <?php echo $__env->make('admin/templates/list_empty', ['colspan' => 7], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                
                </tbody>
            </table>
        </div>
    </div><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/pages/question/list.blade.php ENDPATH**/ ?>