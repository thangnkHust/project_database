<div class="pull-right">
    Coding by <a href="https://colorlib.com/">thangnk</a>
</div>
<div class="clearfix"></div><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/elements/footer.blade.php ENDPATH**/ ?>