<?php echo e($data['name']); ?>

<?php echo e($data['email']); ?>

<?php echo e($data['content']); ?>


<?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/mail/mailfb.blade.php ENDPATH**/ ?>