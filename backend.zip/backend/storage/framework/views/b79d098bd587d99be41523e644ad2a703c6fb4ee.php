<?php
    use App\Helpers\template as template;
    use App\Helpers\hightlight as hightlight;
?>


<div class="x_content">
        <div class="table-responsive">
            <table class="table table-striped jambo_table bulk_action">
                <thead>
                <tr class="headings">
                    <th class="column-title">#</th>
                    <th class="column-title">Name</th>
                    <th class="column-title">Thumb</th>
                    <th class="column-title">Subject</th>
                    <th class="column-title">Status</th>
                    <th class="column-title">Created at</th>
                    <th class="column-title">Updated at</th>
                    <th class="column-title">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php if(count($items) > 0): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $index = $key + 1;
                            $id = $val->id;
                            $name = hightlight::show($val->name, $params['search'], 'name');
                            $thumb = template::showItemThumb($controllerName, $val->thumb, $val->name);
                            $status = template::showItemStatus($controllerName, $id, $val->status);
                            $subject = hightlight::show($val->subject->name, $params['search'], 'subject_id');
                            $createdHistory = template::showItemHistory($val->created_at);
                            $updatedHistory = template::showItemHistory($val->updated_at);
                            $listButtonAction = template::showActionButton($controllerName, $id);
                        ?>

                        <tr class="even pointer">
                            <td class="" width="5%"><?php echo e($index); ?></td>
        
                            <td width="25%">
                                <?php echo $name; ?>

                            </td>

                            <td >
                                <?php echo $thumb; ?>

                            </td>

                            <td width="8%">
                                <?php echo $subject; ?>

                            </td>

                            <td width="10%">
                                <?php echo $status; ?>

                            </td>
        
                            <td width="8%">
                                <?php echo $createdHistory; ?>

                            </td width="8%">
        
                            <td width="8%">
                                <?php echo $updatedHistory; ?>

                            </td>
        
                            <td class="last" width="10%">
                                <?php echo $listButtonAction; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?> 
                    
                    <?php echo $__env->make('admin/templates/list_empty', ['colspan' => 7], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                
                </tbody>
            </table>
        </div>
    </div><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/pages/exam/list.blade.php ENDPATH**/ ?>