<?php
    use App\Helpers\template as template;
    use App\Helpers\hightlight as hightlight;
?>


<div class="x_content">
        <div class="table-responsive">
            <table class="table table-striped jambo_table bulk_action">
                <thead>
                <tr class="headings">
                    <th class="column-title">#</th>
                    <th class="column-title">Name</th>
                    <th class="column-title">Description</th>
                    <th class="column-title">Status</th>
                    <th class="column-title">Created at</th>
                    <th class="column-title">Updated at</th>
                    <th class="column-title">Action</th>
                </tr>
                </thead>
                <tbody>

                <?php if(count($items) > 0): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $index = $key + 1;
                            $id = $val->id;
                            $name = hightlight::show($val->name, $params['search'], 'name');
                            $description = hightlight::show($val->description, $params['search'], 'description');
                            // $name = $val->name;
                            // $description = $val->description;
                            $status = template::showItemStatus($controllerName, $id, $val->status);
                            $createdHistory = template::showItemHistory($val->created_at);
                            $updatedHistory = template::showItemHistory($val->updated_at);
                            $listButtonAction = template::showActionButton($controllerName, $id);
                        ?>

                        <tr class="even pointer">
                            <td class=""><?php echo e($index); ?></td>
        
                            <td width="">
                                <?php echo $name; ?>

                            </td>

                            <td>
                                <?php echo $description; ?>

                            </td>

                            <td>
                                <?php echo $status; ?>

                            </td>
        
                            <td>
                                <?php echo $createdHistory; ?>

                            </td>
        
                            <td>
                                <?php echo $updatedHistory; ?>

                            </td>
        
                            <td class="last" width="10%">
                                <?php echo $listButtonAction; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?> 
                    
                    <?php echo $__env->make('admin/templates/list_empty', ['colspan' => 7], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                
                </tbody>
            </table>
        </div>
    </div><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/pages/subject/list.blade.php ENDPATH**/ ?>