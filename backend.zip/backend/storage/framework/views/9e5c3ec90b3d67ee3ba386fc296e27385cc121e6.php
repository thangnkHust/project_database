
<div class="navbar nav_title" style="border: 0;">
    <a href="<?php echo e(route('home')); ?>" class="site_title"><i class="fa fa-paw"></i> <span>Project News!</span></a>
</div>
<div class="clearfix"></div>
<?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/elements/sidebar_title.blade.php ENDPATH**/ ?>