<?php $__env->startSection('content'); ?>

<h4 class="card-title">Login</h4>

<?php echo $__env->make('web/templates.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('web/templates.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('web/templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo Form::open([
    'method' =>  'POST',
    'url' => route("$controllerName/postlogin"),
    'id' => 'auth-form'
]); ?>


<div class="form-group">
    <label for="email">E-Mail Address</label>

    <input id="email" type="email" class="form-control" name="email" value="" required autofocus>
</div>

<div class="form-group">
    <label for="password">Password
        <a href="forgot.html" class="float-right">
            Forgot Password?
        </a>
    </label>
    <input id="password" type="password" class="form-control" name="password" required data-eye>
</div>

<div class="form-group">
    <label>
        <input type="checkbox" name="remember"> Remember Me
    </label>
</div>

<div class="form-group no-margin">
    <button type="submit" class="btn btn-primary btn-block">
        Login
    </button>
</div>
<div class="margin-top20 text-center">
    Don't have an account? <a href="<?php echo e(route('auth/register')); ?>">Create One</a>
</div>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web/login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/pages/auth/login.blade.php ENDPATH**/ ?>