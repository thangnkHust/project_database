<?php $__env->startSection('content'); ?>
<?php
    use App\Helpers\template as template;
    // $xhtmlButtonFilter = template::showButtonFilter($controllerName, $itemsStatusCount, $params['filter']['status'], $params['search']);
    $xhtmlAreaSearch = template::showAreaSearch($controllerName, $params['search']);
?>
<div class="page-header zvn-page-header clearfix">
    <div class="zvn-page-header-title">
        <h3>Question Management</h3>
    </div>
    <div class="zvn-add-new pull-right">
        <a href="<?php echo e(route($controllerName.'/form')); ?>" class="btn btn-success"><i
                class="fa fa-plus-circle"></i> Add New</a>
    </div>
</div>

<?php echo $__env->make('admin/templates/notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <?php echo $__env->make('admin/templates.x-title', ['title' => 'Filter'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="x_content">
                <div class="row">
                    <div class="col-md-6">
                        
                    </div>
                    <div class="col-md-6">
                        <?php echo $xhtmlAreaSearch; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--box-lists-->
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <?php echo $__env->make('admin/templates.x-title', ['title' => 'List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin/pages/question.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!--end-box-lists-->
<!--box-pagination-->
<?php if(count($items) > 0): ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <?php echo $__env->make('admin/templates.x-title', ['title' => 'Pagination'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('admin/templates.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>
<!--end-box-pagination-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/pages/question/index.blade.php ENDPATH**/ ?>