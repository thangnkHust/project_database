<aside id="colorlib-hero">
    <div class="flexslider">
        <ul class="slides">
            <li style="background-image: url(<?php echo e(asset('front_page/images/img_bg_1.jpg')); ?>);">
                <div class="overlay"></div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-md-offset-2 slider-text">
                            <!-- <div class="slider-text-inner text-center">
                               <h1>Best Online Learning System</h1>
                               <p><a href="#" class="btn btn-primary btn-lg btn-learn">Register Now</a></p>
                           </div> -->
                        </div>
                    </div>
                </div>
            </li>
            <li style="background-image: url(<?php echo e(asset('front_page/images/img_bg_2.jpg')); ?>);">
                <div class="overlay"></div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-md-offset-2 slider-text">
                            <!-- <div class="slider-text-inner text-center">
                               <h1>Online Free Course</h1>
                               <p><a href="#" class="btn btn-primary btn-lg btn-learn">Free Trial</a></p>
                           </div> -->
                        </div>
                    </div>
                </div>
            </li>
            <li style="background-image: url(<?php echo e(asset('front_page/images/img_bg_3.jpg')); ?>);">
                <div class="overlay"></div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-md-offset-2 slider-text">
                            <!-- <div class="slider-text-inner text-center">
                               <h1>Education is a Key to Success</h1>
                               <p><a href="#" class="btn btn-primary btn-lg btn-learn">Register Now</a></p>
                           </div> -->
                        </div>
                    </div>
                </div>
            </li>
            <li style="background-image: url(<?php echo e(asset('front_page/images/img_bg_4.jpg')); ?>);">
                <div class="overlay"></div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-md-offset-2 slider-text">
                            <!-- <div class="slider-text-inner text-center">
                               <h1>Best Online Learning Center</h1>
                               <p><a href="#" class="btn btn-primary btn-lg btn-learn">Register Now</a></p>
                           </div> -->
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</aside><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/web/elements/slider.blade.php ENDPATH**/ ?>