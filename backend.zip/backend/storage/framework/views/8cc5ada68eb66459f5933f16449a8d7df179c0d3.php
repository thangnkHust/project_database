<?php
    // xu ly trong Helper/form.php
    use App\Helpers\form as formTemplate;
    use App\Helpers\template as template;

    // Lay du lieu class chung trong config 
    $formInputAttr = config('test.template.form_input');
    $formLabelAttr = config('test.template.form_label');
    $inputHiddenID = Form::hidden('id', $item['id']);
    $inputHiddenAvatar = Form::hidden('avatar_current', $item['avatar']);
    $inputHiddenTask = Form::hidden('task', 'change_password');

    $elements = [
        // [
        //     'label' => Form::label('old_password', 'Old Password', $formLabelAttr),
        //     'element' => Form::password('old_password', $formInputAttr)
        // ],
        [
            'label' => Form::label('password', 'New Password', $formLabelAttr),
            'element' => Form::password('password', $formInputAttr)
        ],
        [
            'label' => Form::label('password_confirmation', 'Password Confirmation', $formLabelAttr),
            'element' => Form::password('password_confirmation', $formInputAttr)
        ],
        [
            'element' => $inputHiddenID . $inputHiddenTask . Form::submit('Save', ['class' => 'btn btn-success']),
            'type' => 'btn-submit'
        ]
    ]
?>



<div class="col-md-6 col-sm-12 col-xs-12">
    <div class="x_panel">
        <?php echo $__env->make('admin/templates.x-title', ['title' => 'Form Change Password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="x_content">
            
            <?php echo Form::open([
                'url' => route("$controllerName/change-password"),
                'method' => 'POST',
                'accept-charset' => 'UTF-8',
                'enctype' => 'multipart/form-data',
                'class' => 'form-horizontal form-label-left',
                'id' => 'main-form'
                ]); ?>


                
                <?php echo formTemplate::show($elements); ?>


            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/admin/pages/user/form_change_password.blade.php ENDPATH**/ ?>