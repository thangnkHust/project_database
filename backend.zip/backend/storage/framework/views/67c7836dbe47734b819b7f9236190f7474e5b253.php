<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <p>Fullname: <?php echo e($fullname); ?></p>
    <p>Email: <?php echo e($email); ?></p>
    <p>Gửi phản hồi với nội dung: </p>
    <blockquote><?php echo e($content); ?></blockquote>
    <p>--------------------------------------------------------------------------------------------</p>
    <p>Admin cần phản hồi lại feadback</p>
</body>
</html><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/mail/mail_storage.blade.php ENDPATH**/ ?>