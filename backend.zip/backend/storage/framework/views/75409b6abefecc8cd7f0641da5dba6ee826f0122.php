<?php echo e($name); ?>

<?php echo e($email); ?>

<?php echo e($content); ?><?php /**PATH /Users/khacthangdev/Desktop/project_database/backend/resources/views/mailfb.blade.php ENDPATH**/ ?>