{{-- Truong hop khong co data --}}
<tr>
    <td colspan="{{$colspan}}" class="text-center">Du lieu dang duoc cap nhat...</td>
</tr>