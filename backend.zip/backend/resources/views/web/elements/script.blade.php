<!-- jQuery -->
<script src="{{asset('front_page/js/jquery.min.js')}}"></script>
<!-- jQuery Easing -->
<script src="{{asset('front_page/js/jquery.easing.1.3.js')}}"></script>
<!-- Bootstrap -->
<script src="{{asset('front_page/js/bootstrap.min.js')}}"></script>
<!-- Waypoints -->
<script src="{{asset('front_page/js/jquery.waypoints.min.js')}}"></script>
<!-- Stellar Parallax -->
<script src="{{asset('front_page/js/jquery.stellar.min.js')}}"></script>
<!-- Flexslider -->
<script src="{{asset('front_page/js/jquery.flexslider-min.js')}}"></script>
<!-- Owl carousel -->
<script src="{{asset('front_page/js/owl.carousel.min.js')}}"></script>
<!-- Magnific Popup -->
<script src="{{asset('front_page/js/jquery.magnific-popup.min.js')}}"></script>
<script src="{{asset('front_page/js/magnific-popup-options.js')}}"></script>
<!-- Counters -->
<script src="{{asset('front_page/js/jquery.countTo.js')}}"></script>
<!-- Main -->
<script src="{{asset('front_page/js/main.js')}}"></script>
<!-- Modernizr JS -->
<script src="{{asset('front_page/js/modernizr-2.6.2.min.js')}}"></script>
<!-- FOR IE9 below -->
<!--[if lt IE 9]>
<script src="js/respond.min.js"></script>
<![endif]-->
{{-- <script type="text/javascript"
            src="http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_SVG">
    </script> --}}
{{-- <script type="text/javascript" async
  src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-MML-AM_CHTML">
</script> --}}
{{-- Nhung comment with facebook --}}
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v5.0&appId=497438537643875&autoLogAppEvents=1"></script>