
<div class="navbar nav_title" style="border: 0;">
    <a href="{{route('home')}}" class="site_title"><i class="fa fa-paw"></i> <span>Project News!</span></a>
</div>
<div class="clearfix"></div>
