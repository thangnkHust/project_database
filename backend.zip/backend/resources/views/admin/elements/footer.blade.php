<div class="pull-right">
    Coding by <a href="https://colorlib.com/">thangnk</a>
</div>
<div class="clearfix"></div>