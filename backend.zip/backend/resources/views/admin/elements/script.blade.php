<!-- jQuery -->
<script src="{{asset('admin_page/js/jquery/dist/jquery.min.js')}}"></script>
<!-- Bootstrap -->
<script src="{{asset('admin_page/asset/bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- FastClick -->
<script src="{{asset('admin_page/js/fastclick/lib/fastclick.js')}}"></script>
<!-- NProgress -->
<script src="{{asset('admin_page/asset/nprogress/nprogress.js')}}"></script>
<!-- bootstrap-progressbar -->
<script src="{{asset('admin_page/asset/bootstrap-progressbar/bootstrap-progressbar.min.js')}}"></script>
<!-- iCheck -->
<script src="{{asset('admin_page/asset/iCheck/icheck.min.js')}}"></script>
<script src="{{asset('admin_page/js/ckeditor/ckeditor.js')}}"></script>
<!-- Custom Theme Scripts -->
<script src="{{asset('admin_page/js/custom.min.js')}}"></script>
<script src="{{asset('admin_page/js/my-js.js')}}"></script>